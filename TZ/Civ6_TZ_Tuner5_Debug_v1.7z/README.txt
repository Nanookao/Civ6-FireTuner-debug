TZ Civilization 6 Tuner Screens
-------------------------------

These are provided as is.  They are my working folder experimental version.

I added the TZ prefix to make it clear that I modified things.

Basically most of the screens are straight copies from the Civ6 Debug folder
but with the required lua inserted into the OnEnter function and correct
contexts preselected.

I also added Locale conversion where it seemed appropriate.

Dont expect anything to just work.  I didn't test very much.

Extra Screens:
 - TZ Mods
   o Quick screen to help launch the WorldBuilder.  Activate from main menu.
    
 - TZ WB
   o Some helper widgets for selecting and finding starting positions on map

 - TZ Units
   o Some helpers for selecting and finding units on map.  
     Buttons dont work because InGame cannot modify units.  Have to use GameCore_Tuner
    
